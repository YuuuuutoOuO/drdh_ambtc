module data_hidding {
	requires java.desktop;
}